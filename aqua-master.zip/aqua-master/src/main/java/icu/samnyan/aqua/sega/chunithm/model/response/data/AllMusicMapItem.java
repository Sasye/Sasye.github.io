package icu.samnyan.aqua.sega.chunithm.model.response.data;

/**
 * @author samnyan (privateamusement@protonmail.com)
 */
public class AllMusicMapItem {

}
