package icu.samnyan.aqua.api.model.resp.sega.diva;

import lombok.Data;

/**
 * @author samnyan (privateamusement@protonmail.com)
 */
@Data
public class PlayerInfo {
    private int pdId;
    private String playerName;
    private int vocaloidPoints;
}
