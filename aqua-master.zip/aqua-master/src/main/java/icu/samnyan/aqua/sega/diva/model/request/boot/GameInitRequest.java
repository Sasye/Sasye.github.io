package icu.samnyan.aqua.sega.diva.model.request.boot;

import icu.samnyan.aqua.sega.diva.model.request.BaseRequest;
import lombok.Getter;
import lombok.Setter;

/**
 * @author samnyan (privateamusement@protonmail.com)
 */
@Getter
@Setter
public class GameInitRequest extends BaseRequest {

}
