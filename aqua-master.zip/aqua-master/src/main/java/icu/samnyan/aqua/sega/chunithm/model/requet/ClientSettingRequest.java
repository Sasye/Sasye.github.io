package icu.samnyan.aqua.sega.chunithm.model.requet;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ClientSettingRequest {
    private ClientSetting clientSetting;
}
