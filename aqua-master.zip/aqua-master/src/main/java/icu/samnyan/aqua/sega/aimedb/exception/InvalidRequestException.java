package icu.samnyan.aqua.sega.aimedb.exception;

/**
 * @author samnyan (privateamusement@protonmail.com)
 */
public class InvalidRequestException extends Exception {
}
