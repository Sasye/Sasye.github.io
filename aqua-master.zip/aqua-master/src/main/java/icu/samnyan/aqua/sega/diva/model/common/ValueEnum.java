package icu.samnyan.aqua.sega.diva.model.common;

/**
 * @author samnyan (privateamusement@protonmail.com)
 */
public interface ValueEnum {
    int getValue();
}
