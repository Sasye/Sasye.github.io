package icu.samnyan.aqua.sega.diva.exception;

/**
 * @author samnyan (privateamusement@protonmail.com)
 */
public class PvRecordDataException extends RuntimeException {
    public PvRecordDataException(String message) {
        super(message);
    }
}
