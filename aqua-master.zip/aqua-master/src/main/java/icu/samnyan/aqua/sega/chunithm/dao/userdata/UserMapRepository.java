package icu.samnyan.aqua.sega.chunithm.dao.userdata;

import icu.samnyan.aqua.sega.chunithm.model.userdata.UserData;
import icu.samnyan.aqua.sega.chunithm.model.userdata.UserMap;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

/**
 * @author samnyan (privateamusement@protonmail.com)
 */
@Repository
public interface UserMapRepository extends JpaRepository<UserMap, Long> {
    List<UserMap> findAllByUser(UserData user);

    List<UserMap> findAllByUser_Card_ExtId(Long extId);

    Optional<UserMap> findTopByUserAndMapIdOrderByIdDesc(UserData user, int mapId);
}
