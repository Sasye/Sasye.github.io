package icu.samnyan.aqua.sega.diva.model;

/**
 * @author samnyan (privateamusement@protonmail.com)
 */
public interface Internalizable {
    String toInternal();
}
