package icu.samnyan.aqua.sega.diva.exception;

/**
 * @author samnyan (privateamusement@protonmail.com)
 */
public class SessionNotFoundException extends RuntimeException {
}
