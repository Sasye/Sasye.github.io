package icu.samnyan.aqua.sega.diva.controller;

import org.springframework.web.bind.annotation.ControllerAdvice;

/**
 * @author samnyan (privateamusement@protonmail.com)
 */
@ControllerAdvice(basePackages = "icu.samnyan.aqua.sega.diva")
public class DivaControllerAdvice {

}
