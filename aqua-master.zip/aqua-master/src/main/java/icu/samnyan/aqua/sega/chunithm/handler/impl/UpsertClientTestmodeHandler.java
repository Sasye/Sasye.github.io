package icu.samnyan.aqua.sega.chunithm.handler.impl;

import org.springframework.stereotype.Component;

/**
 * @author samnyan (privateamusement@protonmail.com)
 */
@Component
public class UpsertClientTestmodeHandler {
}
