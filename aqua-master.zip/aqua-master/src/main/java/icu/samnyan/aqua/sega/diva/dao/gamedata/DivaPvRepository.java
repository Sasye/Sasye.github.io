package icu.samnyan.aqua.sega.diva.dao.gamedata;

import icu.samnyan.aqua.sega.diva.model.gamedata.Pv;
import org.springframework.data.jpa.repository.JpaRepository;

/**
 * @author  samnyan (privateamusement@protonmail.com)
 */
public interface DivaPvRepository extends JpaRepository<Pv, Integer> {
}
