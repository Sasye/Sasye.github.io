package icu.samnyan.aqua.sega.diva.model.common;

/**
 * @author samnyan (privateamusement@protonmail.com)
 */
public enum StartMode {
    PRE_START,
    START,
    CARD_PROCEDURE
}
