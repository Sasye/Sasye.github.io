package icu.samnyan.aqua.sega.allnet.model.response;

/**
 * @author samnyan (privateamusement@protonmail.com)
 */
public interface PowerOnResponse {
    String toString();
}
