package icu.samnyan.aqua.sega.diva.exception;

/**
 * @author samnyan (privateamusement@protonmail.com)
 */
public class ProfileNotFoundException extends RuntimeException {
}
